# October 14 Update: Streaming Evaluation and Prediction Interface

Date: 2026-10-14  
[简体中文](challenge_update_1014_zh-CN.md)

To simulate data arriving progressively during inference, evaluation now processes query data as a stream: it calls `predict()` once per time bin, in chronological order, passing only the current bin's neural data.

The baseline now provides GRU and WF prediction templates adapted for streaming calls:

- [GRU: challenge_code/Participant/GRU/model.py](challenge_code/Participant/GRU/model.py)
- [WF: challenge_code/Participant/WF/model.py](challenge_code/Participant/WF/model.py)

Neural data and velocity labels are passed as CPU NumPy arrays with dtype `float32`. `C` is the number of neural channels, and `T_support` is the total number of bins across all calibration trials.

## adapt(): Batch calibration

Called once, before prediction, for the **Normal** level only. The model receives the complete labeled support set. Evaluation does not call `adapt()` for Easy or Hard.

```python
model.adapt(X_support, Y_support, task_name=task_name, level=level)
```

| Argument | Contents | Shape |
|---|---|---|
| `X_support` | All calibration neural data | `(T_support, C)` |
| `Y_support` | Corresponding ground-truth velocities, with x and y velocity in the first and second columns | `(T_support, 2)` |

`adapt()` updates the model's state for the current session and returns `None`.

## predict(): One prediction per bin

Evaluation calls `predict()` repeatedly, passing neural data for only the current bin each time. Ground-truth query velocities are not provided.

```python
Y_pred = model.predict(X_query, task_name=task_name, level=level)
```

| Input / output | Contents | Shape |
|---|---|---|
| `X_query` | Neural data for the current bin | `(1, C)` |
| `Y_pred` | Velocity prediction for the current bin, with x and y velocity in the first and second columns | `(1, 2)` |

The templates return NumPy arrays with dtype `float32`; predictions must contain finite values. Models may retain history between calls to construct temporal features for the current prediction.

Both methods receive `task_name` and `level` as keyword arguments: `task_name` is `MA_CO` or `MA_RT`, and `level` is `easy`, `normal`, or `hard`.

Call `reset()` once at the beginning of each session. For Normal, batch `adapt()` follows, then `predict()` is called for each bin. Preserve the model's history between successive predictions within the same session.

