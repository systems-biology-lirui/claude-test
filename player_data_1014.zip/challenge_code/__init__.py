"""Motor BCI cross-day decoding challenge."""
