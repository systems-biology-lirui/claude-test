"""Participant-facing templates."""
