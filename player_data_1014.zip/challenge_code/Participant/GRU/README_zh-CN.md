# GRU 基线

[English](README_EN.md) · [参赛者指南](../README_zh-CN.md)

## 训练

从项目根目录运行：

```powershell
python -m pip install -r challenge_code/Participant/GRU/requirements.txt
python -m challenge_code.Participant.GRU.train --data-root challenge_data
```

默认模型使用 25-bin 因果窗口和单层、128 隐藏单元的 GRU。训练结果分别保存在 `challenge_code/Participant/GRU/MA_CO/model.pt` 和 `challenge_code/Participant/GRU/MA_RT/model.pt`。模型文件包含推理所需的参数和预处理统计量。

Normal 档位使用的输出层适配系数可通过训练命令的 `--adapt-alpha` 设置，默认值为 `0.1`；该值随模型文件保存。

## 使用与提交

Easy 和 Hard 使用训练好的模型直接预测。Normal 提供带标签的校准数据时，基线通过 `adapt()` 调整当前会话的输出层；该调整只保存在内存中。

提交时从本目录复制 `model.py`、`requirements.txt`、`MA_CO/model.pt` 和 `MA_RT/model.pt`，并保留两个任务子目录。接口说明见[提交接口](../submission_template/README_zh-CN.md)。
