# GRU baseline

[中文](README_zh-CN.md) · [Participant guide](../README_EN.md)

## Training

Run these commands from the project root:

```powershell
python -m pip install -r challenge_code/Participant/GRU/requirements.txt
python -m challenge_code.Participant.GRU.train --data-root challenge_data
```

The default model uses a 25-bin causal window and a single-layer GRU with 128 hidden units. Training saves `challenge_code/Participant/GRU/MA_CO/model.pt` and `challenge_code/Participant/GRU/MA_RT/model.pt`. Each model file includes the parameters and preprocessing statistics needed for inference.

Set the output-head adaptation strength used in Normal with `--adapt-alpha` when training. Its default is `0.1`, and the value is saved with the model.

## Use and submission

Easy and Hard predict directly with the trained model. When Normal supplies labeled calibration data, the baseline adjusts its output layer through `adapt()` for the current session. This adjustment stays in memory.

To submit, copy this directory's `model.py`, `requirements.txt`, `MA_CO/model.pt`, and `MA_RT/model.pt`, preserving both task subdirectories. See the [submission interface](../submission_template/README_EN.md).
