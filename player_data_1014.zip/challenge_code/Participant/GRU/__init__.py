"""GRU baseline for the three-level challenge."""
