"""Submission-time GRU decoder with calibration z-score and ridge-head adaptation."""

from __future__ import annotations

from pathlib import Path

import numpy as np
import torch
from torch import nn

torch.backends.cudnn.enabled = True


TASK_NAMES = ("MA_CO", "MA_RT")
CALIBRATION_RIDGE_ALPHA = 0.1
NEURAL_STD_MIN = 1e-4


class GRUDecoder(nn.Module):
    def __init__(self, input_dim: int, hidden_dim: int = 128, num_layers: int = 1,
                 dropout: float = 0.0, input_dropout: float = 0.2,
                 output_dim: int = 2):
        super().__init__()
        self.input_dropout = nn.Dropout(input_dropout)
        self.gru = nn.GRU(
            input_dim, hidden_dim, num_layers=num_layers,
            dropout=dropout if num_layers > 1 else 0.0, batch_first=True,
        )
        self.head = nn.Linear(hidden_dim, output_dim)

    def features(self, x: torch.Tensor, lengths: torch.Tensor | None = None):
        recurrent, _ = self.gru(self.input_dropout(x))
        if lengths is None:
            return recurrent[:, -1]
        index = lengths.to(recurrent.device, dtype=torch.long) - 1
        return recurrent[torch.arange(len(recurrent), device=recurrent.device), index]

    def forward(self, x: torch.Tensor, lengths: torch.Tensor | None = None):
        return self.head(self.features(x, lengths))


def _safe_load(path: Path):
    try:
        return torch.load(path, map_location="cpu", weights_only=True)
    except TypeError:
        return torch.load(path, map_location="cpu")


def _as_numpy(value) -> np.ndarray:
    if isinstance(value, torch.Tensor):
        return value.detach().cpu().numpy()
    return np.asarray(value)


class SubmissionModel:
    def __init__(self, model_dir: str | Path):
        self.bundles = {}
        for task in TASK_NAMES:
            path = Path(model_dir) / task / "model.pt"
            if path.is_file():
                self.bundles[task] = _safe_load(path)
        if not self.bundles:
            raise FileNotFoundError(f"No GRU model.pt found below {model_dir}")
        self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        self.model = None
        self.task_name = None
        self.neural_mean = None
        self.neural_std = None
        self.velocity_mean = None
        self.velocity_std = None

    def reset(self, *, task_name: str, level: str) -> None:
        if task_name not in self.bundles:
            raise KeyError(f"No trained GRU model for {task_name!r}")
        bundle = self.bundles[task_name]
        self.model = GRUDecoder(**bundle["model_config"])
        self.model.load_state_dict(bundle["state_dict"], strict=True)
        self.model.to(self.device).eval()
        self.task_name = task_name
        self.neural_mean = np.asarray(_as_numpy(bundle["neural_mean"]), np.float32)
        self.neural_std = np.asarray(_as_numpy(bundle["neural_std"]), np.float32)
        self.velocity_mean = np.asarray(_as_numpy(bundle["velocity_mean"]), np.float32)
        self.velocity_std = np.asarray(_as_numpy(bundle["velocity_std"]), np.float32)
        ## update: add streaming buffer
        self._stream_x = np.empty((0, len(self.neural_mean)), dtype=np.float32)

    def _features(self, x: np.ndarray, mode="adapt") -> torch.Tensor:
        if self.model is None or self.task_name is None:
            raise RuntimeError("reset() must be called before prediction")
        x = np.asarray(x, dtype=np.float32)
        if x.ndim != 2 or x.shape[1] != len(self.neural_mean) or not np.isfinite(x).all():
            raise ValueError(f"Invalid GRU input shape/content: {x.shape}")
        if len(x) == 0:
            return torch.empty((0, self.model.head.in_features), dtype=torch.float32)
        
        window_len = int(self.bundles[self.task_name]["window_len"])
        input_x = x.copy()

        if mode == "predict":
            # update: add streaming buffer (x is a single time point)
            self._stream_x = np.concatenate([self._stream_x, x], axis=0)[-window_len:]
            input_x = self._stream_x.copy()
        data = torch.from_numpy(np.ascontiguousarray((input_x - self.neural_mean) / self.neural_std))

        if mode == "predict":
            with torch.inference_mode():
                return self.model.features(
                    data.unsqueeze(0).to(self.device)
                )

        outputs = []
        with torch.inference_mode():
            # Prefix endpoints are shorter than a complete window and must use
            # the same right-padding + valid-length convention as training.
            prefix_count = min(window_len - 1, len(data))
            if prefix_count:
                prefix = torch.zeros(
                    prefix_count, window_len, data.shape[1], dtype=data.dtype
                )
                for end in range(prefix_count):
                    prefix[end, : end + 1] = data[: end + 1]
                lengths = torch.arange(1, prefix_count + 1, device=self.device)
                outputs.append(self.model.features(prefix.to(self.device), lengths).cpu())

            # Complete windows are built as a view and evaluated in batches.
            if len(data) >= window_len:
                windows = data.unfold(0, window_len, 1).permute(0, 2, 1)
                for start in range(0, len(windows), 512):
                    batch = windows[start : start + 512].to(self.device)
                    outputs.append(self.model.features(batch).cpu())
        return torch.cat(outputs)

    def _predict_base(self, x: np.ndarray) -> np.ndarray:
        hidden = self._features(x, mode="predict").to(self.device)
        with torch.inference_mode():
            prediction_z = self.model.head(hidden).cpu().numpy()
        return (prediction_z * self.velocity_std + self.velocity_mean).astype(np.float32)

    def adapt(self, X_support: np.ndarray, Y_support: np.ndarray, *,
              task_name: str, level: str) -> None:
        x = np.asarray(X_support, dtype=np.float32)
        y = np.asarray(Y_support, dtype=np.float32)
        if level in ("easy", "hard"):
            if len(x):
                raise ValueError("Easy/Hard must not receive support samples")
            return
        if y.shape != (len(x), 2) or len(x) == 0:
            raise ValueError(f"Invalid support arrays: X={x.shape}, Y={y.shape}")

        # The winning grid-search configuration uses the current session's
        # calibration neural statistics instead of the historical train stats.
        self.neural_mean = x.mean(axis=0).astype(np.float32)
        self.neural_std = x.std(axis=0).astype(np.float32)
        self.neural_std[self.neural_std < NEURAL_STD_MIN] = 1.0

        # Freeze the recurrent backbone and refit only its linear head in the
        # original normalized-velocity space. Ridge strength follows the grid
        # search convention: alpha multiplied by the number of time bins.
        hidden = self._features(x).numpy().astype(np.float64)
        target = ((y - self.velocity_mean) / self.velocity_std).astype(np.float64)
        design = np.column_stack([hidden, np.ones(len(hidden), dtype=np.float64)])
        penalty = np.eye(design.shape[1], dtype=np.float64)
        alpha = float(self.bundles[self.task_name].get(
            "adapt_alpha", CALIBRATION_RIDGE_ALPHA
        ))
        if not np.isfinite(alpha) or alpha <= 0:
            raise ValueError(f"Invalid GRU adaptation alpha: {alpha}")
        penalty *= alpha * len(design)
        penalty[-1, -1] = 0.0
        coefficients = np.linalg.solve(
            design.T @ design + penalty,
            design.T @ target,
        )
        with torch.no_grad():
            self.model.head.weight.copy_(
                torch.from_numpy(coefficients[:-1].T.astype(np.float32)).to(self.device)
            )
            self.model.head.bias.copy_(
                torch.from_numpy(coefficients[-1].astype(np.float32)).to(self.device)
            )

    def predict(self, X_query: np.ndarray, *, task_name: str,
                level: str) -> np.ndarray:
        if task_name != self.task_name:
            raise RuntimeError("reset() task does not match predict() task")
        result = self._predict_base(X_query)
        result = np.asarray(result, dtype=np.float32)
        if result.shape != (len(X_query), 2) or not np.isfinite(result).all():
            raise ValueError(f"Invalid GRU prediction: {result.shape}")
        return result
