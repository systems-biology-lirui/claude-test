"""Train task-specific historical GRU models from public Easy NWB files."""

from __future__ import annotations

import argparse
from bisect import bisect_right
import copy
import json
import os
from pathlib import Path
import random
import shutil
import time

import numpy as np
import torch
from torch.utils.data import DataLoader, Dataset

from ..data import load_nwb_session
from .model import GRUDecoder, TASK_NAMES

# The shared cluster environment has an incompatible cuDNN RNN runtime.
# Keep the native CUDA GRU path as the safe default, including when this module
# is imported and train_task() is called outside main().
torch.backends.cudnn.enabled = False


def seed_all(seed):
    random.seed(seed); np.random.seed(seed); torch.manual_seed(seed)
    if torch.cuda.is_available(): torch.cuda.manual_seed_all(seed)


def load_trials(root: Path):
    records = []
    for path in sorted(root.rglob("*.nwb")):
        data = load_nwb_session(path)
        valid = data.trial_ids[data.trial_ids >= 0]
        _, first = np.unique(valid, return_index=True)
        ids = valid[np.sort(first)]
        for trial_id in ids:
            mask = data.trial_ids == trial_id
            records.append((data.neural[mask], data.velocity[mask], path.parent.name))
        print(f"  loaded {path.name}: {len(ids)} trials", flush=True)
    if not records:
        raise FileNotFoundError(f"No trials found below {root}")
    return records


def stats(records, item):
    arrays = [record[item].astype(np.float64) for record in records]
    count = sum(map(len, arrays)); total = sum(a.sum(0) for a in arrays)
    total_sq = sum(np.square(a).sum(0) for a in arrays)
    mean = total / count
    std = np.sqrt(np.maximum(total_sq / count - mean**2, 0.0)); std[std < 1e-6] = 1.0
    return mean.astype(np.float32), std.astype(np.float32)


class Windows(Dataset):
    def __init__(self, records, nmean, nstd, vmean, vstd, window_len, stride):
        self.records, self.nmean, self.nstd = records, nmean, nstd
        self.vmean, self.vstd = vmean, vstd
        self.window_len, self.stride, self.cumulative = window_len, stride, []
        total = 0
        for x, _, _ in records:
            total += (len(x) + stride - 1) // stride
            self.cumulative.append(total)
    def __len__(self): return self.cumulative[-1]
    def __getitem__(self, index):
        ri = bisect_right(self.cumulative, index)
        previous = self.cumulative[ri - 1] if ri else 0
        x, y, _ = self.records[ri]
        end = min((index - previous + 1) * self.stride - 1, len(x) - 1)
        left = max(0, end - self.window_len + 1); length = end - left + 1
        window = np.zeros((self.window_len, x.shape[1]), np.float32)
        window[:length] = (x[left:end + 1] - self.nmean) / self.nstd
        target = (y[end] - self.vmean) / self.vstd
        return torch.from_numpy(window), torch.from_numpy(target), torch.tensor(length)


@torch.inference_mode()
def validation_loss(model, loader, device):
    model.eval(); squared = 0.0; count = 0
    for x, y, lengths in loader:
        x, y, lengths = x.to(device), y.to(device), lengths.to(device)
        error = torch.square(model(x, lengths) - y)
        squared += error.sum().item(); count += y.numel()
    return squared / count


def train_task(task, data_root, output_root, args):
    seed_all(args.seed)
    records = load_trials(data_root / "public" / task / "easy" / "heldin")
    # Every source date contributes validation trials, avoiding a validation set
    # made entirely from only the latest recording day.
    train_records, val_records = [], []
    sessions = sorted({r[2] for r in records})
    for session in sessions:
        subset = [r for r in records if r[2] == session]
        n_val = max(1, round(len(subset) * args.val_fraction))
        train_records.extend(subset[:-n_val]); val_records.extend(subset[-n_val:])
    nmean, nstd = stats(train_records, 0); vmean, vstd = stats(train_records, 1)
    train_data = Windows(train_records, nmean, nstd, vmean, vstd, args.window_len, args.stride)
    val_data = Windows(val_records, nmean, nstd, vmean, vstd, args.window_len, 1)
    options = dict(batch_size=args.batch_size, num_workers=args.num_workers)
    train_loader = DataLoader(train_data, shuffle=True, **options)
    val_loader = DataLoader(val_data, shuffle=False, **options)
    config = dict(input_dim=len(nmean), hidden_dim=args.hidden_dim,
                  num_layers=args.num_layers, dropout=args.dropout,
                  input_dropout=args.input_dropout, output_dim=2)
    device = torch.device("cuda" if args.device == "auto" and torch.cuda.is_available() else
                          "cpu" if args.device == "auto" else args.device)
    model = GRUDecoder(**config).to(device)
    optimizer = torch.optim.AdamW(model.parameters(), lr=args.lr, weight_decay=args.weight_decay)
    best_loss, best_state, best_epoch, stale = float("inf"), None, 0, 0
    started = time.perf_counter()
    for epoch in range(1, args.epochs + 1):
        model.train()
        for x, y, lengths in train_loader:
            x, y, lengths = x.to(device), y.to(device), lengths.to(device)
            optimizer.zero_grad(set_to_none=True)
            loss = torch.square(model(x, lengths) - y).mean()
            loss.backward(); torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
            optimizer.step()
        current = validation_loss(model, val_loader, device)
        print(f"  {task} epoch {epoch:03d}: val_loss={current:.6f}", flush=True)
        if current < best_loss - args.min_delta:
            best_loss, best_epoch, stale = current, epoch, 0
            best_state = {k: v.detach().cpu().clone() for k, v in model.state_dict().items()}
        else:
            stale += 1
            if stale >= args.patience: break
    if best_state is None: raise RuntimeError("Training did not produce a checkpoint")
    task_dir = output_root / task; task_dir.mkdir(parents=True, exist_ok=True)
    bundle = dict(format_version=1, task_name=task, model_config=config,
                  state_dict=best_state,
                  neural_mean=torch.from_numpy(nmean),
                  neural_std=torch.from_numpy(nstd),
                  velocity_mean=torch.from_numpy(vmean),
                  velocity_std=torch.from_numpy(vstd),
                  window_len=args.window_len, adapt_alpha=args.adapt_alpha)
    temporary = task_dir / "model.pt.tmp"; final = task_dir / "model.pt"
    torch.save(bundle, temporary); os.replace(temporary, final)
    metrics = dict(task_name=task, sessions=sessions, n_train_trials=len(train_records),
                   n_validation_trials=len(val_records), best_epoch=best_epoch,
                   validation_loss=best_loss, elapsed_seconds=time.perf_counter()-started)
    (task_dir / "metrics.json").write_text(json.dumps(metrics, indent=2), encoding="utf-8")
    entry = output_root / "model.py"
    source_entry = Path(__file__).resolve().parent / "model.py"
    if entry.resolve() != source_entry.resolve():
        shutil.copy2(source_entry, entry)
    print(f"  saved {final}", flush=True)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--data-root", type=Path, default=Path("data/challenge_data"))
    parser.add_argument("--output-dir", type=Path, default=Path(__file__).resolve().parent)
    parser.add_argument("--task", choices=("all", *TASK_NAMES), default="all")
    parser.add_argument("--epochs", type=int, default=100)
    parser.add_argument("--patience", type=int, default=15)
    parser.add_argument("--min-delta", type=float, default=1e-5)
    parser.add_argument("--batch-size", type=int, default=128)
    parser.add_argument("--window-len", type=int, default=25)
    parser.add_argument("--stride", type=int, default=1)
    parser.add_argument("--val-fraction", type=float, default=0.1)
    parser.add_argument("--hidden-dim", type=int, default=128)
    parser.add_argument("--num-layers", type=int, default=1)
    parser.add_argument("--dropout", type=float, default=0.0)
    parser.add_argument("--input-dropout", type=float, default=0.2)
    parser.add_argument("--lr", type=float, default=3e-4)
    parser.add_argument("--weight-decay", type=float, default=1e-2)
    parser.add_argument("--adapt-alpha", type=float, default=0.1)
    parser.add_argument("--device", default="auto")
    cudnn_group = parser.add_mutually_exclusive_group()
    cudnn_group.add_argument(
        "--disable-cudnn",
        dest="disable_cudnn",
        action="store_true",
        help="Use PyTorch's native CUDA GRU path (default)",
    )
    cudnn_group.add_argument(
        "--enable-cudnn",
        dest="disable_cudnn",
        action="store_false",
        help="Use cuDNN RNN kernels when the CUDA environment supports them",
    )
    parser.set_defaults(disable_cudnn=True)
    parser.add_argument("--num-workers", type=int, default=0)
    parser.add_argument("--seed", type=int, default=42)
    args = parser.parse_args()
    if not 0 < args.val_fraction < 1 or args.window_len < 1 or args.stride < 1:
        raise SystemExit("Require 0 < val-fraction < 1 and positive window/stride")
    if not np.isfinite(args.adapt_alpha) or args.adapt_alpha <= 0:
        raise SystemExit("Require a positive, finite --adapt-alpha")
    torch.backends.cudnn.enabled = not args.disable_cudnn
    if args.disable_cudnn:
        print("cuDNN disabled; using the native PyTorch CUDA GRU implementation", flush=True)
    else:
        print("cuDNN enabled for GRU training", flush=True)
    tasks = TASK_NAMES if args.task == "all" else (args.task,)
    for task in tasks:
        train_task(task, args.data_root.resolve(), args.output_dir.resolve(), args)


if __name__ == "__main__":
    main()
