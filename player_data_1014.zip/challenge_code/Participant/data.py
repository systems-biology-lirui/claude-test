"""Standalone NWB reader for participant training.

Copied from the platform reader so the Participant directory can be distributed
independently. This module contains no evaluation or private-data discovery code.
"""
from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
import numpy as np


@dataclass(frozen=True)
class SessionData:
    neural: np.ndarray
    velocity: np.ndarray
    trial_ids: np.ndarray
    timestamps: np.ndarray


def load_nwb_session(nwb_path: str | Path) -> SessionData:
    try:
        from pynwb import NWBHDF5IO
    except ImportError as exc:
        return _load_nwb_session_h5py(nwb_path)

    nwb_path = Path(nwb_path)
    with NWBHDF5IO(str(nwb_path), "r") as io:
        nwbfile = io.read()
        binned_spikes = nwbfile.acquisition.get("binned_spikes")
        if binned_spikes is None:
            raise ValueError(f"NWB missing acquisition/binned_spikes: {nwb_path}")
        neural = np.asarray(binned_spikes.data[:], dtype=np.float32)
        timestamps = np.asarray(binned_spikes.timestamps[:], dtype=np.float64)

        cursor_vel = nwbfile.acquisition.get("cursor_vel")
        if cursor_vel is None:
            raise ValueError(f"NWB missing acquisition/cursor_vel: {nwb_path}")
        velocity = np.column_stack([
            np.asarray(cursor_vel.time_series["x"].data[:]).reshape(-1),
            np.asarray(cursor_vel.time_series["y"].data[:]).reshape(-1),
        ]).astype(np.float32)

        trial_ids = np.full(len(timestamps), -1, dtype=np.int64)
        trials = nwbfile.trials.to_dataframe()
        required = {"start_time", "stop_time", "trial_id"}
        if not required.issubset(trials.columns):
            raise ValueError(f"NWB trials table must contain {sorted(required)}: {nwb_path}")
        for row in trials.itertuples(index=False):
            mask = (timestamps >= row.start_time) & (timestamps <= row.stop_time)
            trial_ids[mask] = int(row.trial_id)

    if neural.ndim == 2 and neural.shape[0] != len(timestamps) and neural.shape[1] == len(timestamps):
        neural = neural.T
    if neural.ndim != 2:
        raise ValueError(f"Neural data must have shape (T, C), got {neural.shape}")
    if not (len(neural) == len(velocity) == len(trial_ids) == len(timestamps)):
        raise ValueError(
            f"Time dimension mismatch in {nwb_path}: neural={len(neural)}, "
            f"velocity={len(velocity)}, trials={len(trial_ids)}, timestamps={len(timestamps)}"
        )
    if velocity.shape != (len(neural), 2):
        raise ValueError(f"Velocity must have shape (T, 2), got {velocity.shape}")
    if not np.isfinite(neural).all() or not np.isfinite(velocity).all():
        raise ValueError(f"NWB contains NaN or Inf: {nwb_path}")
    return SessionData(neural, velocity, trial_ids, timestamps)


def _load_nwb_session_h5py(nwb_path: str | Path) -> SessionData:
    """Read the challenge NWB layout when pynwb is unavailable."""
    try:
        import h5py
    except ImportError as exc:
        raise ImportError("Reading NWB requires pynwb or h5py") from exc

    nwb_path = Path(nwb_path)
    with h5py.File(str(nwb_path), "r") as nwb:
        def read(dataset: str) -> np.ndarray:
            if dataset not in nwb:
                raise ValueError(f"NWB missing {dataset}: {nwb_path}")
            return np.asarray(nwb[dataset])

        neural = read("acquisition/binned_spikes/data").astype(np.float32)
        timestamps = read("acquisition/binned_spikes/timestamps").astype(np.float64)
        velocity = np.column_stack([
            read("acquisition/cursor_vel/x/data").reshape(-1),
            read("acquisition/cursor_vel/y/data").reshape(-1),
        ]).astype(np.float32)
        source_trial_ids = read("intervals/trials/trial_id").astype(np.int64)
        starts = read("intervals/trials/start_time").astype(np.float64)
        stops = read("intervals/trials/stop_time").astype(np.float64)

    if neural.ndim == 2 and neural.shape[0] != len(timestamps) and neural.shape[1] == len(timestamps):
        neural = neural.T
    trial_ids = np.full(len(timestamps), -1, dtype=np.int64)
    for trial_id, start, stop in zip(source_trial_ids, starts, stops):
        trial_ids[(timestamps >= start) & (timestamps <= stop)] = int(trial_id)
    if neural.ndim != 2 or neural.shape[0] != len(timestamps):
        raise ValueError(f"Neural data must have shape (T, C), got {neural.shape}")
    if velocity.shape != (len(timestamps), 2):
        raise ValueError(f"Velocity must have shape (T, 2), got {velocity.shape}")
    if not np.isfinite(neural).all() or not np.isfinite(velocity).all():
        raise ValueError(f"NWB contains NaN or Inf: {nwb_path}")
    return SessionData(neural, velocity, trial_ids, timestamps)

