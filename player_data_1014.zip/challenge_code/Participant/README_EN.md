# Participant guide

[中文](README_zh-CN.md) · [Challenge overview](../../challenge_readme_EN.md)

## Data layout

Run the commands below from the project root and keep this directory layout:

```text
.
├── challenge_code/
│   └── Participant/
│       ├── GRU/
│       ├── WF/
│       └── submission_template/
└── challenge_data/
    └── public/
        ├── MA_CO/easy/heldin/...
        └── MA_RT/easy/heldin/...
```

The public NWB files contain neural activity and two-dimensional velocity labels. `--data-root` points to `challenge_data`. Keep the existing Python files and directory structure inside `Participant`.

## Use or train a baseline

GRU and WF baselines and their model files are provided. You may use an existing model. To train one again, run its commands from the project root:

```powershell
python -m pip install -r challenge_code/Participant/GRU/requirements.txt
python -m challenge_code.Participant.GRU.train --data-root challenge_data
```

```powershell
python -m pip install -r challenge_code/Participant/WF/requirements.txt
python -m challenge_code.Participant.WF.train --data-root challenge_data
```

By default, trained models are saved under the corresponding `challenge_code/Participant/GRU` or `challenge_code/Participant/WF` directory. See the [GRU](GRU/README_EN.md) and [WF](WF/README_EN.md) guides for details.

## Prepare a submission

Choose one model. Put its `model.py`, `requirements.txt`, and model files for both `MA_CO` and `MA_RT` into one submission directory, preserving the task subdirectories. GRU uses `model.pt`; WF uses `model.pkl`. For example:

```text
submission-directory/
├── model.py
├── requirements.txt
├── MA_CO/
│   └── model.pt
└── MA_RT/
    └── model.pt
```

The example shows GRU. For WF, replace both `model.pt` files with `model.pkl`. `train.py` and `data.py` are for local training and need not be submitted. If you build your own model, follow the [submission interface](submission_template/README_EN.md).
