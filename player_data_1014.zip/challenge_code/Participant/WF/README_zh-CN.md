# WF 基线

[English](README_EN.md) · [参赛者指南](../README_zh-CN.md)

## 训练

从项目根目录运行：

```powershell
python -m pip install -r challenge_code/Participant/WF/requirements.txt
python -m challenge_code.Participant.WF.train --data-root challenge_data
```

默认训练采用因果指数平滑、8-bin 历史窗口和 Ridge 回归，并从公开会话训练的候选模型中选择一个。训练结果分别保存在 `challenge_code/Participant/WF/MA_CO/model.pkl` 和 `challenge_code/Participant/WF/MA_RT/model.pkl`。模型文件保存数值系数和预处理统计量。

## 使用与提交

Easy 和 Hard 使用训练好的模型直接预测。Normal 提供带标签的校准数据时，基线通过 `adapt()` 为当前会话拟合回归模型；该调整只保存在内存中。

提交时从本目录复制 `model.py`、`requirements.txt`、`MA_CO/model.pkl` 和 `MA_RT/model.pkl`，并保留两个任务子目录。接口说明见[提交接口](../submission_template/README_zh-CN.md)。
