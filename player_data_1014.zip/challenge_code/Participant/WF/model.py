"""Submission-time Wiener-filter decoder with session-local Ridge adaptation.

The historical task model is loaded from ``<model_dir>/<task>/model.pkl``.
Normal blends train/calibration neural statistics and fit a strongly
regularized session-local Ridge decoder; Hard keeps the historical decoder.
"""

from __future__ import annotations

from pathlib import Path
import pickle

import numpy as np
from numpy.lib.stride_tricks import sliding_window_view
from sklearn.linear_model import Ridge


TASK_NAMES = ("MA_CO", "MA_RT")
CALIBRATION_BLEND_WEIGHT = 0.75
CALIBRATION_RIDGE_ALPHA = 10000.0
NEURAL_STD_MIN = 1e-6


class _FrozenRegressor:
    """Use stored numeric coefficients without unpickling a sklearn object."""

    def __init__(self, coef, intercept, dtype):
        self.coef = np.asarray(coef, dtype=dtype)
        self.intercept = np.asarray(intercept, dtype=dtype)
        if self.coef.ndim != 2 or self.coef.shape[0] != 2 or self.intercept.shape != (2,):
            raise ValueError("Invalid frozen WF regressor coefficients")

    def predict(self, features: np.ndarray) -> np.ndarray:
        return np.asarray(features, dtype=self.coef.dtype) @ self.coef.T + self.intercept


def smooth_features(
    features: np.ndarray, tau_ms: float = 240.0, bin_size_ms: float = 20.0
) -> np.ndarray:
    if features.ndim != 2:
        raise ValueError(f"Expected neural array (T, C), got {features.shape}")
    kernel_times = np.arange(0.0, tau_ms, bin_size_ms, dtype=np.float64)
    kernel = np.exp(-kernel_times / tau_ms)
    kernel /= kernel.sum()
    result = np.empty_like(features, dtype=np.float32)
    for channel in range(features.shape[1]):
        result[:, channel] = np.convolve(
            features[:, channel], kernel, mode="full"
        )[: len(features)]
    return result


def causal_feature_matrix(features: np.ndarray, window_len: int) -> np.ndarray:
    """Create one causal flattened history window for every time bin."""
    if window_len < 1 or len(features) == 0:
        raise ValueError("window_len and the number of samples must be positive")
    if window_len == 1:
        return np.ascontiguousarray(features)
    padded = np.concatenate(
        [np.repeat(features[:1], window_len - 1, axis=0), features], axis=0
    )
    windows = sliding_window_view(padded, window_len, axis=0)
    windows = np.transpose(windows, (0, 2, 1))
    return np.ascontiguousarray(windows.reshape(len(features), -1))


def _validate_xy(x: np.ndarray, y: np.ndarray | None = None):
    x = np.asarray(x, dtype=np.float32)
    if x.ndim != 2 or not np.isfinite(x).all():
        raise ValueError(f"Neural data must be finite with shape (T, C), got {x.shape}")
    if y is None:
        return x
    y = np.asarray(y, dtype=np.float32)
    if y.shape != (len(x), 2) or not np.isfinite(y).all():
        raise ValueError(f"Velocity must be finite with shape {(len(x), 2)}, got {y.shape}")
    return x, y


class SubmissionModel:
    def __init__(self, model_dir: str | Path):
        self.model_dir = Path(model_dir)
        self.base_models: dict[str, dict] = {}
        for task in TASK_NAMES:
            path = self.model_dir / task / "model.pkl"
            if path.is_file():
                with path.open("rb") as stream:
                    self.base_models[task] = pickle.load(stream)
        if not self.base_models:
            raise FileNotFoundError(
                f"No WF checkpoint found below {self.model_dir}; train MA_CO/MA_RT first"
            )
        self.task_name: str | None = None
        self.active_regressor = None
        self.active_mean = None
        self.active_std = None

    def _base(self, task_name: str) -> dict:
        if task_name not in self.base_models:
            raise KeyError(f"No trained WF model for {task_name!r}")
        return self.base_models[task_name]

    def reset(self, *, task_name: str, level: str) -> None:
        bundle = self._base(task_name)
        self.task_name = task_name
        if bundle.get("format_version") == 2:
            self.active_regressor = _FrozenRegressor(
                bundle["coef"], bundle["intercept"], bundle["regressor_dtype"]
            )
        else:
            self.active_regressor = bundle["regressor"]
        self.active_mean = np.asarray(bundle["neural_mean"], np.float32).reshape(1, -1)
        self.active_std = np.asarray(bundle["neural_std"], np.float32).reshape(1, -1)
        # update: add streaming buffer
        kernel_len = len(np.arange(
            0.0,
            float(bundle["smooth_tau_ms"]),
            float(bundle["bin_size_ms"]),
            dtype=np.float64,
        ))
        self._stream_keep = kernel_len + int(bundle["window_len"]) - 1
        self._stream_x = np.empty(
            (0, int(bundle["n_channels"])), dtype=np.float32
        )

    def _features(self, x: np.ndarray, bundle: dict) -> np.ndarray:
        x = _validate_xy(x)
        expected = int(bundle["n_channels"])
        if x.shape[1] != expected:
            raise ValueError(f"Expected {expected} neural channels, got {x.shape[1]}")
        smoothed = smooth_features(
            x, float(bundle["smooth_tau_ms"]), float(bundle["bin_size_ms"])
        )
        normalized = (smoothed - self.active_mean) / self.active_std
        return causal_feature_matrix(normalized, int(bundle["window_len"]))

    def adapt(
        self, X_support: np.ndarray, Y_support: np.ndarray, *,
        task_name: str, level: str,
    ) -> None:
        x, y = _validate_xy(X_support, Y_support)
        if level in ("easy", "hard"):
            if len(x):
                raise ValueError("Easy/Hard must not receive support samples")
            return
        if len(x) == 0:
            raise ValueError(f"{level} requires non-empty support data")
        bundle = self._base(task_name)
        smoothed = smooth_features(
            x, float(bundle["smooth_tau_ms"]), float(bundle["bin_size_ms"])
        )
        calibration_mean = smoothed.mean(axis=0, keepdims=True).astype(np.float32)
        calibration_std = smoothed.std(axis=0, keepdims=True).astype(np.float32)
        calibration_std[calibration_std < NEURAL_STD_MIN] = 1.0
        weight = CALIBRATION_BLEND_WEIGHT
        self.active_mean = (
            (1.0 - weight) * self.active_mean + weight * calibration_mean
        ).astype(np.float32)
        self.active_std = (
            (1.0 - weight) * self.active_std + weight * calibration_std
        ).astype(np.float32)
        self.active_std[self.active_std < NEURAL_STD_MIN] = 1.0
        features = causal_feature_matrix(
            (smoothed - self.active_mean) / self.active_std,
            int(bundle["window_len"]),
        )
        regressor = Ridge(
            alpha=CALIBRATION_RIDGE_ALPHA, fit_intercept=True, solver="lsqr"
        )
        regressor.fit(features, y)
        self.active_regressor = regressor

    def predict(
        self, X_query: np.ndarray, *, task_name: str, level: str
    ) -> np.ndarray:
        if self.task_name != task_name or self.active_regressor is None:
            raise RuntimeError("reset() must be called before predict()")

        x = _validate_xy(X_query)
        if len(x) == 0:
            return np.empty((0, 2), dtype=np.float32)
        bundle = self._base(task_name)
        expected = int(bundle["n_channels"])
        if x.shape != (len(x), expected):
            raise ValueError(
                f"Streaming predict expects {(len(x), expected)}, got {x.shape}"
            )
        # update: add streaming buffer
        self._stream_x = np.concatenate(
            [self._stream_x, x], axis=0
        )[-self._stream_keep:]

        features = self._features(self._stream_x, bundle)[-1:]
        prediction = np.asarray(self.active_regressor.predict(features), np.float32)

        if prediction.shape != (len(x), 2) or not np.isfinite(prediction).all():
            raise ValueError(f"Invalid WF prediction shape/content: {prediction.shape}")
        return prediction
