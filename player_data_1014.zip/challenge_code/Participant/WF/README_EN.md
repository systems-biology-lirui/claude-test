# WF baseline

[中文](README_zh-CN.md) · [Participant guide](../README_EN.md)

## Training

Run these commands from the project root:

```powershell
python -m pip install -r challenge_code/Participant/WF/requirements.txt
python -m challenge_code.Participant.WF.train --data-root challenge_data
```

Default training uses causal exponential smoothing, an 8-bin history window, and Ridge regression, then selects among models trained from public sessions. Training saves `challenge_code/Participant/WF/MA_CO/model.pkl` and `challenge_code/Participant/WF/MA_RT/model.pkl`. Each model file contains numeric coefficients and preprocessing statistics.

## Use and submission

Easy and Hard predict directly with the trained model. When Normal supplies labeled calibration data, the baseline fits a regressor for the current session through `adapt()`. This adjustment stays in memory.

To submit, copy this directory's `model.py`, `requirements.txt`, `MA_CO/model.pkl`, and `MA_RT/model.pkl`, preserving both task subdirectories. See the [submission interface](../submission_template/README_EN.md).
