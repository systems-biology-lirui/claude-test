"""Wiener-filter/Ridge baseline for the three-level challenge."""
