"""Train frozen historical WF/Ridge baselines from public Easy NWB files."""

from __future__ import annotations

import argparse
import json
from pathlib import Path
import pickle
import shutil
import time

import numpy as np
from sklearn.linear_model import Ridge

from ..data import load_nwb_session
from .model import TASK_NAMES, causal_feature_matrix, smooth_features


def ordered_trials(trial_ids: np.ndarray) -> list[int]:
    valid = trial_ids[trial_ids >= 0]
    _, first = np.unique(valid, return_index=True)
    return [int(value) for value in valid[np.sort(first)]]


def load_session(path: Path) -> tuple[list[tuple[np.ndarray, np.ndarray]], int]:
    data = load_nwb_session(path)
    trials = []
    for trial_id in ordered_trials(data.trial_ids):
        mask = data.trial_ids == trial_id
        trials.append((data.neural[mask], data.velocity[mask]))
    if not trials:
        raise ValueError(f"No trials found in {path}")
    return trials, data.neural.shape[1]


def fit_stats(trials):
    count = sum(len(x) for x, _ in trials)
    total = sum((x.astype(np.float64).sum(0) for x, _ in trials))
    total_sq = sum((np.square(x.astype(np.float64)).sum(0) for x, _ in trials))
    mean = total / count
    std = np.sqrt(np.maximum(total_sq / count - mean**2, 0.0))
    std[std < 1e-6] = 1.0
    return mean.astype(np.float32)[None, :], std.astype(np.float32)[None, :]


def build_examples(trials, mean, std, window_len, tau_ms):
    features, targets = [], []
    for x, y in trials:
        smoothed = smooth_features(x, tau_ms=tau_ms)
        features.append(causal_feature_matrix((smoothed - mean) / std, window_len))
        targets.append(y)
    return np.concatenate(features), np.concatenate(targets)


def r2_mean(y, prediction):
    ss_res = np.square(y - prediction).sum(0)
    ss_tot = np.square(y - y.mean(0, keepdims=True)).sum(0)
    return float(np.mean(1.0 - np.divide(ss_res, ss_tot, out=np.zeros(2), where=ss_tot > 1e-12)))


def train_task(task: str, data_root: Path, output_root: Path, args) -> None:
    nwb_root = data_root / "public" / task / "easy" / "heldin"
    paths = sorted(nwb_root.rglob("*.nwb"))
    if not paths:
        raise FileNotFoundError(f"No public Easy NWB found below {nwb_root}")
    sessions, channels = [], None
    for path in paths:
        trials, found_channels = load_session(path)
        channels = found_channels if channels is None else channels
        if found_channels != channels:
            raise ValueError(f"Channel mismatch in {path}")
        sessions.append((path, trials))
        print(f"  {task}: loaded {path.name}, trials={len(trials)}", flush=True)

    # Match the reference baseline: train one candidate per source session and
    # retain the candidate with the best mean performance on the other days.
    candidates = []
    started = time.perf_counter()
    for source_path, source_trials in sessions:
        smoothed_trials = [(smooth_features(x, args.tau_ms), y) for x, y in source_trials]
        mean, std = fit_stats(smoothed_trials)
        x_train, y_train = build_examples(
            source_trials, mean, std, args.window_len, args.tau_ms
        )
        model = Ridge(alpha=args.alpha, fit_intercept=True, solver="lsqr")
        model.fit(x_train, y_train)
        scores = []
        for target_path, target_trials in sessions:
            if target_path == source_path:
                continue
            target_smoothed = [(smooth_features(x, args.tau_ms), y) for x, y in target_trials]
            target_mean, target_std = fit_stats(target_smoothed)
            x_test, y_test = build_examples(
                target_trials, target_mean, target_std, args.window_len, args.tau_ms
            )
            scores.append(r2_mean(y_test, model.predict(x_test)))
        score = float(np.mean(scores)) if scores else float("nan")
        print(f"  candidate {source_path.stem}: cross-day mean R2={score:.4f}", flush=True)
        candidates.append((score, source_path, model, mean, std))

    best = max(candidates, key=lambda item: -np.inf if np.isnan(item[0]) else item[0])
    score, source_path, model, mean, std = best
    bundle = {
        "format_version": 2,
        "task_name": task,
        "coef": model.coef_.tolist(),
        "intercept": np.asarray(model.intercept_).tolist(),
        "regressor_dtype": str(model.coef_.dtype),
        "neural_mean": mean.tolist(),
        "neural_std": std.tolist(),
        "n_channels": int(channels),
        "window_len": int(args.window_len),
        "alpha": float(args.alpha),
        "smooth_tau_ms": float(args.tau_ms),
        "bin_size_ms": 20.0,
        "selected_source": source_path.stem,
        "cross_day_validation_r2": score,
    }
    task_dir = output_root / task
    task_dir.mkdir(parents=True, exist_ok=True)
    with (task_dir / "model.pkl").open("wb") as stream:
        pickle.dump(bundle, stream, protocol=pickle.HIGHEST_PROTOCOL)
    metrics = {
        "task_name": task,
        "n_sessions": len(sessions),
        "selected_source": source_path.stem,
        "cross_day_validation_r2": score,
        "alpha": args.alpha,
        "window_len": args.window_len,
        "smooth_tau_ms": args.tau_ms,
        "elapsed_seconds": time.perf_counter() - started,
    }
    (task_dir / "metrics.json").write_text(
        json.dumps(metrics, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    entry = output_root / "model.py"
    source_entry = Path(__file__).resolve().parent / "model.py"
    if entry.resolve() != source_entry.resolve():
        shutil.copy2(source_entry, entry)
    print(f"  saved {task_dir / 'model.pkl'}", flush=True)


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--data-root", type=Path, default=Path("data/challenge_data"))
    parser.add_argument("--output-dir", type=Path, default=Path(__file__).resolve().parent)
    parser.add_argument("--task", choices=("all", *TASK_NAMES), default="all")
    parser.add_argument("--alpha", type=float, default=100.0)
    parser.add_argument("--window-len", type=int, default=8)
    parser.add_argument("--tau-ms", type=float, default=240.0)
    args = parser.parse_args()
    if args.alpha < 0 or args.window_len < 1 or args.tau_ms <= 0:
        raise SystemExit("alpha >= 0, window-len >= 1, and tau-ms > 0 are required")
    tasks = TASK_NAMES if args.task == "all" else (args.task,)
    for task in tasks:
        train_task(task, args.data_root.resolve(), args.output_dir.resolve(), args)


if __name__ == "__main__":
    main()
