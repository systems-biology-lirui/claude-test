# 提交接口

[English](README_EN.md) · [参赛者指南](../README_zh-CN.md)

提交目录中的 `model.py` 必须定义 `SubmissionModel` 类。该类需实现 `__init__(model_dir)`、`reset()`、`adapt()` 和 `predict()`。`model_dir` 是提交目录的路径，可用于加载随模型提交的权重和预处理参数。

## 调用方式

每个会话先调用 `reset()`，再进行预测。Normal 档位提供部分带标签的校准 trial 时，会先调用 `adapt()`：

```python
model = SubmissionModel(model_dir)
model.reset(task_name=task_name, level=level)
if level == "normal":
    model.adapt(X_support, Y_support, task_name=task_name, level=level)
Y_pred = model.predict(X_query, task_name=task_name, level=level)
```

`task_name` 为 `MA_CO` 或 `MA_RT`；`level` 为 `easy`、`normal` 或 `hard`。方法中的 `task_name` 和 `level` 均以关键字参数传入。Easy 和 Hard 不提供校准数据。

`X_support` 与 `X_query` 是形状为 `(T, C)` 的神经数据，`Y_support` 是形状为 `(T, 2)` 的速度标签。`T` 为时间点数，`C` 为神经通道数。`predict()` 应返回与 `X_query` 等长、形状为 `(T, 2)` 的有限 `float32` 速度预测。

## 模型状态

`reset()` 应为新会话恢复初始模型状态。`adapt()` 只调整当前会话的状态，不应影响后续会话，也不得向提交目录写入文件。推理所需的权重和预处理参数须包含在提交目录内。

提供的 `model.py` 是接口模板，权重加载、校准和预测仍需自行实现。模板使用 `deepcopy` 恢复状态；若你的模型对象不支持复制，可在 `reset()` 中重新构建模型并加载初始权重。
