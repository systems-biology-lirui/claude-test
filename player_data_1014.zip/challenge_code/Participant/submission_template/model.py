from __future__ import annotations

from copy import deepcopy
from pathlib import Path

import numpy as np


class SubmissionModel:
    """Participant API. Load immutable historical weights in __init__."""

    def __init__(self, model_dir: str | Path):
        self.model_dir = Path(model_dir)
        self.initial_states: dict[str, dict] = {}
        self.state: dict = {}
        self.session_cache: dict = {}
        self.task_name: str | None = None
        self.level: str | None = None

        # Load MA_CO / MA_RT historical checkpoints here.
        # For each task, save ALL initial model and preprocessing state, e.g.:
        # self.initial_states[task] = {
        #     "model": loaded_model,
        #     "preprocessing": loaded_preprocessing_parameters,
        # }
        # adapt() and predict() must use self.state, leaving initial_states unchanged.
        # Store temporary hidden states and other caches in self.session_cache.

    def reset(self, *, task_name: str, level: str) -> None:
        """Restore the frozen historical model before every evaluation session."""
        if task_name not in self.initial_states:
            raise KeyError(
                f"No initial state loaded for {task_name!r}; "
                "load its model and preprocessing parameters in __init__()"
            )

        # Calibration may mutate the working copy, never the historical state.
        self.state = deepcopy(self.initial_states[task_name])
        self.session_cache = {}
        self.task_name = task_name
        self.level = level

    def adapt(
        self,
        X_support: np.ndarray,
        Y_support: np.ndarray,
        *,
        task_name: str,
        level: str,
    ) -> None:
        """Called only for Normal, with labeled calibration data."""
        if X_support.shape[0] != Y_support.shape[0]:
            raise ValueError("Support neural data and labels must have equal length")
        if level != "normal":
            raise ValueError("Only Normal supports evaluation-time adaptation")
        # Fit self.state only in memory. Keep self.initial_states unchanged.
        # Never write adapted weights into model_dir.

    def predict(
        self,
        X_query: np.ndarray,
        *,
        task_name: str,
        level: str,
    ) -> np.ndarray:
        """Return float32 velocity predictions with shape (T, 2)."""
        # Run inference using self.state; use self.session_cache for temporary state.
        raise NotImplementedError
