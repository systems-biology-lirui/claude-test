# Submission interface

[中文](README_zh-CN.md) · [Participant guide](../README_EN.md)

`model.py` in the submission directory must define a `SubmissionModel` class. Implement `__init__(model_dir)`, `reset()`, `adapt()`, and `predict()`. `model_dir` is the submission directory path and can be used to load the submitted weights and preprocessing parameters.

## Call sequence

`reset()` is called before prediction for each session. When Normal supplies some labeled calibration trials, `adapt()` is called first:

```python
model = SubmissionModel(model_dir)
model.reset(task_name=task_name, level=level)
if level == "normal":
    model.adapt(X_support, Y_support, task_name=task_name, level=level)
Y_pred = model.predict(X_query, task_name=task_name, level=level)
```

`task_name` is `MA_CO` or `MA_RT`; `level` is `easy`, `normal`, or `hard`. Pass `task_name` and `level` as keyword arguments. Easy and Hard have no calibration data.

`X_support` and `X_query` contain neural data with shape `(T, C)`; `Y_support` contains velocity labels with shape `(T, 2)`. `T` is the number of time bins and `C` the number of neural channels. `predict()` must return finite `float32` velocity predictions with shape `(T, 2)`, matching the length of `X_query`.

## Model state

`reset()` must restore the initial model state for a new session. `adapt()` may change only the current session's state; it must not affect later sessions or write files into the submission directory. Include all weights and preprocessing parameters needed for inference in the submission directory.

The provided `model.py` is an interface template. You must implement weight loading, calibration, and prediction. The template uses `deepcopy` to restore state; if your model cannot be copied, reconstruct it and reload its initial weights in `reset()`.
