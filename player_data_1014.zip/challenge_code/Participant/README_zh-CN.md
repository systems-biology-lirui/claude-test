# 参赛者指南

[English](README_EN.md) · [挑战说明](../../challenge_readme_zh-CN.md)

## 数据目录

请从本项目根目录运行下文的命令，并保留以下结构：

```text
.
├── challenge_code/
│   └── Participant/
│       ├── GRU/
│       ├── WF/
│       └── submission_template/
└── challenge_data/
    └── public/
        ├── MA_CO/easy/heldin/...
        └── MA_RT/easy/heldin/...
```

公开 NWB 文件包含神经活动和二维速度标签。`--data-root` 指向 `challenge_data`；请保留 `Participant` 内原有的 Python 文件和目录结构。

## 使用或训练基线

目录中提供 GRU 和 WF 两种基线及其模型文件。可直接选用已有模型；如需重新训练，请从项目根目录运行对应命令：

```powershell
python -m pip install -r challenge_code/Participant/GRU/requirements.txt
python -m challenge_code.Participant.GRU.train --data-root challenge_data
```

```powershell
python -m pip install -r challenge_code/Participant/WF/requirements.txt
python -m challenge_code.Participant.WF.train --data-root challenge_data
```

默认训练结果写入相应的 `challenge_code/Participant/GRU` 或 `challenge_code/Participant/WF` 目录。具体用法见 [GRU](GRU/README_zh-CN.md) 和 [WF](WF/README_zh-CN.md)。

## 准备提交文件

选择一个模型，将其 `model.py`、`requirements.txt` 及 `MA_CO`、`MA_RT` 两个任务的模型文件放入同一个提交目录，保留任务子目录。GRU 使用 `model.pt`，WF 使用 `model.pkl`。例如：

```text
提交目录/
├── model.py
├── requirements.txt
├── MA_CO/
│   └── model.pt
└── MA_RT/
    └── model.pt
```

上例为 GRU；使用 WF 时将两个 `model.pt` 换成 `model.pkl`。`train.py` 和 `data.py` 用于本地训练，无需放入提交目录。自行实现模型时，请遵循[提交接口](submission_template/README_zh-CN.md)。
