# NHP Cross-Day Motor Decoding Challenge: Participant Guide

[中文](challenge_readme_zh-CN.md)

## Tasks and public data

The challenge uses neural activity to predict two-dimensional cursor velocity. It has two tasks: `MA_CO` (center-out) and `MA_RT` (random target). Public NWB files for training are under `challenge_data/public/`. Keep the directory layout:

```text
.
├── challenge_code/
│   └── Participant/
│       ├── GRU/
│       ├── WF/
│       └── submission_template/
└── challenge_data/
    └── public/
        ├── MA_CO/easy/heldin/...
        └── MA_RT/easy/heldin/...
```

Easy and Hard have no calibration labels; the model predicts directly. Normal supplies some labeled calibration trials that the model may use to adapt for the current session. See the [submission interface](challenge_code/Participant/submission_template/README_EN.md) for the model calls in each level.

## Use a baseline

The project includes GRU and WF baselines and their model files. You can use an existing model or train one again on the public data. Python 3.10 is recommended. Run the commands from this directory, choosing only the baseline you need:

**GRU**

```powershell
python -m pip install -r challenge_code/Participant/GRU/requirements.txt
python -m challenge_code.Participant.GRU.train --data-root challenge_data
```

**WF**

```powershell
python -m pip install -r challenge_code/Participant/WF/requirements.txt
python -m challenge_code.Participant.WF.train --data-root challenge_data
```

By default, training writes model files to the selected baseline's `MA_CO` and `MA_RT` subdirectories. See the [GRU](challenge_code/Participant/GRU/README_EN.md) and [WF](challenge_code/Participant/WF/README_EN.md) guides for model details.

## Prepare a submission

Your submission directory must contain `model.py`, `requirements.txt`, and model files for both tasks, preserving the `MA_CO` and `MA_RT` subdirectories. For GRU, the layout is:

```text
submission-directory/
├── model.py
├── requirements.txt
├── MA_CO/
│   └── model.pt
└── MA_RT/
    └── model.pt
```

For WF, both task model files are named `model.pkl`. You may also implement your own model, but `model.py` must define a `SubmissionModel` class that follows the [submission interface](challenge_code/Participant/submission_template/README_EN.md). Include all weights and preprocessing parameters needed for inference in the submission directory. Public training data, `train.py`, and `data.py` need not be submitted.
