# 10 月 14 日更新说明：流式评测与预测接口

日期：2026-10-14  
[English](challenge_update_1014_EN.md)

为了模拟真实推理时数据逐步到达的过程，评测代码已改为流式处理：按时间顺序逐个时间点（bin）调用 `predict()`，每次仅传入当前 bin 的神经数据。

本 baseline 已提供适配流式调用的 GRU 和 WF 预测模板，位置如下：

- [GRU：challenge_code/Participant/GRU/model.py](challenge_code/Participant/GRU/model.py)
- [WF：challenge_code/Participant/WF/model.py](challenge_code/Participant/WF/model.py)

神经数据和速度标签均以 CPU 上的 NumPy `float32` 数组传入。`C` 表示神经通道数，`T_support` 表示全部校准 trial 合计的 bin 数量。

## adapt()：批量校准

仅在 **Normal** 档位、开始预测前调用一次，将完整的带标签 support 数据传给模型。Easy 和 Hard 不调用 `adapt()`。

```python
model.adapt(X_support, Y_support, task_name=task_name, level=level)
```

| 参数 | 内容 | Shape |
|---|---|---|
| `X_support` | 全部校准神经数据 | `(T_support, C)` |
| `Y_support` | 对应的真实速度标签，两列依次为 x、y 方向速度 | `(T_support, 2)` |

`adapt()` 更新模型在当前 session 内的状态，返回 `None`。

## predict()：逐 bin 预测

评测程序连续调用 `predict()`，每次只传入当前一个 bin 的神经数据，不传入 query 的真实速度标签。

```python
Y_pred = model.predict(X_query, task_name=task_name, level=level)
```

| 输入 / 输出 | 内容 | Shape |
|---|---|---|
| `X_query` | 当前 bin 的神经数据 | `(1, C)` |
| `Y_pred` | 当前 bin 的速度预测，两列依次为 x、y 方向速度 | `(1, 2)` |

模板返回 NumPy `float32` 数组，预测值须为有限数值。模型可在连续调用之间保存历史，以构造当前预测所需的时序特征。

两个方法均通过关键字参数接收 `task_name` 和 `level`：`task_name` 为 `MA_CO` 或 `MA_RT`，`level` 为 `easy`、`normal` 或 `hard`。

每个 session 开始时调用一次 `reset()`；Normal 随后进行批量 `adapt()`，再逐 bin 调用 `predict()`。同一 session 内连续预测时保留模型历史状态。

