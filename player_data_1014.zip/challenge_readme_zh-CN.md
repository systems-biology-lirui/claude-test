# NHP 跨天运动解码挑战：参赛者指南

[English](challenge_readme_EN.md)

## 任务与公开数据

本挑战使用神经活动预测二维光标速度，包含两个任务：`MA_CO`（center-out）和 `MA_RT`（随机目标）。可用于训练的公开数据是 NWB 文件，位于 `challenge_data/public/`。请保留原有目录结构：

```text
.
├── challenge_code/
│   └── Participant/
│       ├── GRU/
│       ├── WF/
│       └── submission_template/
└── challenge_data/
    └── public/
        ├── MA_CO/easy/heldin/...
        └── MA_RT/easy/heldin/...
```

Easy 和 Hard 不提供校准标签，模型直接预测。Normal 会提供部分带标签的校准 trial，模型可在当前会话中使用这些数据进行适配。各档位的模型调用要求见[提交接口](challenge_code/Participant/submission_template/README_zh-CN.md)。

## 使用基线

项目提供 GRU 和 WF 两种基线及对应的模型文件，可以选用已有模型，也可以使用公开数据重新训练。建议使用 Python 3.10 环境。从本目录运行以下命令；按需选择一种基线即可：

**GRU**

```powershell
python -m pip install -r challenge_code/Participant/GRU/requirements.txt
python -m challenge_code.Participant.GRU.train --data-root challenge_data
```

**WF**

```powershell
python -m pip install -r challenge_code/Participant/WF/requirements.txt
python -m challenge_code.Participant.WF.train --data-root challenge_data
```

训练结果默认写入相应基线的 `MA_CO` 和 `MA_RT` 子目录。模型说明见 [GRU](challenge_code/Participant/GRU/README_zh-CN.md) 和 [WF](challenge_code/Participant/WF/README_zh-CN.md)。

## 准备提交

提交目录须包含 `model.py`、`requirements.txt` 和两个任务的模型文件，并保留 `MA_CO`、`MA_RT` 子目录。例如，GRU 的提交结构为：

```text
提交目录/
├── model.py
├── requirements.txt
├── MA_CO/
│   └── model.pt
└── MA_RT/
    └── model.pt
```

使用 WF 时，两个任务的模型文件为 `model.pkl`。也可以自行实现模型，但 `model.py` 必须定义符合[提交接口](challenge_code/Participant/submission_template/README_zh-CN.md)的 `SubmissionModel` 类。请将推理所需的权重和预处理参数一同放入提交目录；公开训练数据、`train.py` 和 `data.py` 无需提交。
